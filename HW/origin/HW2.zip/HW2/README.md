# CS182 HW2

## Introduction

HW2 consists of two parts: writing exercises and coding exercises.

### Part One: Writing (40 PTS)

1. Finish the problems in `writing/hw2_writing.pdf`.
2. Upload your answers as "yourname_hw2_writing.pdf" to Gradescope.

### Part Two: Coding (20 PTS)

1. Finish `coding/hw2_linear_regression.ipynb`. 
2. Please export the jupyter notebook as a PDF named  "yourname_hw2_coding.pdf" and upload it to Gradescope.

## Due date

Tuesday Nov. 14 at 23:59 (CST)
