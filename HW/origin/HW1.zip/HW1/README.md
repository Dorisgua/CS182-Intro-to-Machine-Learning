# CS182 HW1

## Introduction

HW1 consists of two parts: writing exercises and coding exercises.

### Part One: Writing (30 PTS)

1. Finish the problems in `writing/hw1_writing.pdf`.
2. Upload your answers as "name_hw1_writing.pdf" to Gradescope.

### Part Two: Coding (70 PTS)

1. Finish `coding/hw1_coding.ipynb`. 
2. Upload your answers as "name_hw1_coding.pdf" to Gradescope.

## Due date
 
Thursday, Oct. 26 at 23:59 (CST)
