# This is the coding part of HW1
- We mainly borrow the assignment project from CS231n.
- You may run it on your local environment or on Google Colab.
- Please follow the instrunciton in `datasets` to download cifar-10 dataset
- Please follow the instruction in `hw1_coding.ipynb` to complete this assignment.
- Please export the jupyter notebook as PDF and submit on gradescope
- May you have any difficulties in setting up environment, please refer to setup.md
