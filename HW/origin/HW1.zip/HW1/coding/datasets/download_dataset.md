请从https://epan.shanghaitech.edu.cn/l/LFOqpv下载数据集并在此目录解压
解压后数据集目录应为： `datasets(此目录)/cifar-10-batches-py/(数据集文件)`